Revision History
================

** REMEMBER TO MIGRATE **

0.X.X 2015-XX-XX

- 

0.1.3 2015-12-07

- Fix thumbnail image elongation in Chrome on screens >= 1200px wide
- Require that ShinyApp name and slug are unique
- Update README with more complete and accurate instructions
- Prepare for distribution via PyPI


0.1.2 2015-04-21

- Replace line breaks in slide description field with appropriate HTML


0.1.1 2015-04-19

- Improve django CMS integration and styling


0.1.0 2015-04-16

- A Django app for adding R Shiny apps to a Django site with django CMS-specific features
