from django.db import models
# from django.core.exceptions import ValidationError

from cms.models import CMSPlugin
from filer.fields.file import FilerFileField
from filer.fields.image import FilerImageField
from taggit.managers import TaggableManager


class DataFile(models.Model):
    name = models.CharField('name',
        # blank=True,
        # help_text='Enter a concise, yet descriptive, name for this data file record.<br>'
        #           'If left blank, this data file record will be named after the selected file.',
        help_text='Enter a concise, yet descriptive, name for this data file record.',
        max_length=255,
        unique=True,
    )

    slug = models.SlugField(
        help_text='Enter a unique <a href="https://en.wikipedia.org/wiki/'
                  'Semantic_URL#Slug" target="_blank">slug</a> for this data file.<br>'
                  '(Prepopulated in the admin page based on the data file name.)',
        unique=True,
    )

    file = FilerFileField(
        help_text='Select/Upload a data file.',
        on_delete=models.PROTECT,
        related_name='%(app_label)s_%(class)s',
        # unique=True,
# WARNINGS:
# cms_lab_data.DataFile.file: (fields.W342) Setting unique=True on a ForeignKey has the same effect as using a OneToOneField.
#     HINT: ForeignKey(unique=True) is usually better served by a OneToOneField.
# cms_lab_data.DataFileSet.data_files: (fields.W340) null has no effect on ManyToManyField.
    )


    # external_file?

    description = models.TextField('description',
        blank=True,
        help_text='Enter a description of this data file.',
    )

    is_published = models.BooleanField('Published',
        default=True,
        help_text='Show data file on site?'
    )

    tags = TaggableManager(
        blank=True,
        help_text='Add keyword tags that represent this data file.',
    )

    # # def clean(self):
    # def clean(self):
    #     """
    #     """
    #     data = self.cleaned_data
    #     # super(DataFile, self).clean()

    #     if data['id'] is None \
    #     and data['name'] == '' \
    #     and len(DataFile.objects.filter(name=data['file'].original_filename)) > 0:
    #         raise ValidationError(
    #             'A data file record named after the selected file already exists. '
    #             'Either use that record, enter a unique name, or select a different file.'
    #         )

    #     return data

    # def save(self, *args, **kwargs):
    #     """
    #     Before saving, set name to the filename if name is blank.
    #     """
    #     if self.name == '':
    #         self.name = self.file.original_filename

    #     super().save(*args, **kwargs)

    def file_size_fmt(self, suffix='B'):
        """
        Convert file size to human-readable format
        Based on http://stackoverflow.com/a/1094933/996114
        """
        size = self.file.size
        for unit in ['','K','M','G','T','P','E','Z']:
            if abs(size) < 1024.0:
                return '%.1f %s%s' % (size, unit, suffix)
            size /= 1024.0
        return '%.1f %s%s' % (size, 'Y', suffix)

    def __str__(self):
        return self.name

    class Meta:
        ordering = ('name',)


class DataFileSet(models.Model):
    name = models.CharField('name',
        help_text="Enter a unique name for this Data File Set.<br>"
                  "This won't be displayed on the site.",
        max_length=255,
        unique=True,
    )

    slug = models.SlugField(
        help_text='Enter a unique <a href="https://en.wikipedia.org/wiki/'
                  'Semantic_URL#Slug" target="_blank">slug</a> for this data file set.<br>'
                  '(Prepopulated in the admin page based on the data file set name.)',
        unique=True,
    )

    label = models.CharField('label',
        default='Data',
        help_text='Enter a label for this Data File Set.<br>'
                  'This will be the heading displayed above the data files.',
        max_length=255,
    )

    description = models.TextField('description',
        blank=True,
        help_text='Enter a description of this data set.',
    )

    image = FilerImageField(
        blank=True,
        null=True,
        help_text='Select/Upload a representative image for this data set.',
        on_delete=models.PROTECT,
        related_name='%(app_label)s_%(class)s',
    )

    data_files = models.ManyToManyField(DataFile,
        blank=True,
        null=True,
    )

    pagination = models.PositiveIntegerField('files / page',
        default=10,
        help_text="How many data files should be displayed per page? "
                  "To show all at once, enter '0'.",
    )
# Include Max lines, too?
    max_words_file_description = models.PositiveIntegerField('max words',
        default=40,
        help_text='Enter the maximum # of words to display for a data file description.<br>'
                  'Truncated descriptions will have a button for displaying more info.',
    )

    word_buffer_file_description = models.PositiveIntegerField('word buffer',
        default=10,
        help_text="The 'word buffer' prevents descriptions from being truncated "
                  "if they are only slightly over the 'max words' cutoff.<br>"
                  "For example, with 'max words' of 40 and a 'word buffer' of 10, "
                  "descriptions longer than 50 words will be truncated to 40.",
    )

    is_published = models.BooleanField('Published',
        default=True,
        help_text='Show data file set on site?'
    )

    searchable = models.BooleanField('searchable',
        default=True,
        help_text='Enable data file search and keyword filter.'
    )

    tags = TaggableManager(
        blank=True,
        help_text='Add keyword tags that represent this data set.',
    )

    def published_data_files(self):
        return self.data_files.filter(is_published=True)

    def __str__(self):
        return self.name

    class Meta:
        ordering = ('name',)


class DataFileSetPlugin(CMSPlugin):
    data_file_set = models.ForeignKey('cms_lab_data.DataFileSet',
        limit_choices_to={'is_published': True},
        on_delete=models.PROTECT,
    )

    def __str__(self):
        return self.data_file_set.name


# class FileType(models.Model):
    # try to have it auto-choose
